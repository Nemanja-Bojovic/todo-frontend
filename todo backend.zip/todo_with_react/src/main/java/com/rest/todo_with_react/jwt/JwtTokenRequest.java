package com.rest.todo_with_react.jwt;

public record JwtTokenRequest(String username, String password) {}


