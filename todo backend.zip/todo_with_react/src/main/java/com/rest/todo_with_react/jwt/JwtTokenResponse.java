package com.rest.todo_with_react.jwt;

public record JwtTokenResponse(String token) {}


